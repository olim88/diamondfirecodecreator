# ReloadHotbar
Loads any changes made to the `hotbar.nbt` file when the "Saved Hotbars" tab in the creative menu is clicked.  
Changes made in Minecraft are not saved until the game closes, this is vanilla behavior. Changing this would require more work than I really feel like doing right now, do `/data get entity @s SelectedItem` if you need to bring an item out of Minecraft and edit it. 

Uses the [Fabric launcher](https://fabricmc.net/use/), does not use the Fabric API.
