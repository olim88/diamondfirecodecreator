package ml.cheeseos.reloadhotbar;

import net.fabricmc.api.ModInitializer;

public class ReloadHotbar implements ModInitializer {
	@Override
	public void onInitialize() {
		// this does nothing, but Fabric crashes if we don't have this class
	}
}
